// CONFIGURAZIONE DI FROSTLINE
// Prima di pubblicare: testMode = false e sostituisci gli ID di prova con i tuoi (AdMob).
window.FROSTLINE_CONFIG = {
  testMode: true,
  appId: 'com.tuonome.frostline',
  admobAppId:     'ca-app-pub-3940256099942544~3347511713', // ID di PROVA Google
  bannerId:       'ca-app-pub-3940256099942544/6300978111', // ID di PROVA Google
  interstitialId: 'ca-app-pub-3940256099942544/1033173712', // ID di PROVA Google
  rewardedId:     'ca-app-pub-3940256099942544/5224354917', // ID di PROVA Google
  removeAdsProductId: 'remove_ads', // stesso ID del prodotto creato in Play Console
  privacyUrl: 'https://TUOUSERNAME.github.io/frostline/privacy.html',
  supportEmail: 'tuaemail@example.com'
};
