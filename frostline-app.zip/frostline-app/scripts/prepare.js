// Copia Three.js in locale (l'app deve funzionare offline) e controlla la configurazione.
const fs = require('fs'), path = require('path');
const cfg = require('./load-config')();
const root = path.join(__dirname, '..');

const src = path.join(root, 'node_modules', 'three', 'build', 'three.min.js');
if (!fs.existsSync(src)) { console.error('Esegui prima: npm install'); process.exit(1); }
fs.mkdirSync(path.join(root, 'www', 'lib'), { recursive: true });
fs.copyFileSync(src, path.join(root, 'www', 'lib', 'three.min.js'));
console.log('OK  three.min.js copiato in www/lib');

// Sincronizza l'appId in capacitor.config.json
const capPath = path.join(root, 'capacitor.config.json');
const cap = JSON.parse(fs.readFileSync(capPath, 'utf8'));
cap.appId = cfg.appId; fs.writeFileSync(capPath, JSON.stringify(cap, null, 2));

const problems = [];
if (cfg.appId.includes('tuonome')) problems.push('appId: cambia "com.tuonome.frostline" con un ID tuo e definitivo (non si può cambiare dopo la pubblicazione).');
if (!cfg.testMode) {
  ['admobAppId', 'bannerId', 'interstitialId', 'rewardedId'].forEach(k => {
    if (String(cfg[k]).includes('3940256099942544')) problems.push(k + ' è ancora un ID di prova Google.');
  });
  if (cfg.privacyUrl.includes('TUOUSERNAME')) problems.push('privacyUrl non è stato impostato.');
  if (cfg.supportEmail.includes('example.com')) problems.push('supportEmail non è stato impostato.');
}
if (problems.length) {
  console.error('\nDA SISTEMARE in www/config.js prima di pubblicare:\n - ' + problems.join('\n - '));
  if (!cfg.testMode) process.exit(1);
  console.warn('\n(testMode è attivo: puoi continuare per i test, ma NON pubblicare così.)');
} else console.log('OK  configurazione pronta');
