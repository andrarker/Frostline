// Dopo "cap add android": blocca in verticale, aggiunge l'ID AdMob e i permessi.
const fs = require('fs'), path = require('path');
const cfg = require('./load-config')();
const mf = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(mf)) { console.error('Manca la cartella android. Esegui: npx cap add android'); process.exit(1); }
let x = fs.readFileSync(mf, 'utf8');

if (!x.includes('screenOrientation')) {
  x = x.replace(/(<activity\b)/, '$1 android:screenOrientation="portrait"');
}
if (!x.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  x = x.replace('</application>',
    '    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="' + cfg.admobAppId + '"/>\n    </application>');
} else {
  x = x.replace(/(com\.google\.android\.gms\.ads\.APPLICATION_ID"\s+android:value=")[^"]*/, '$1' + cfg.admobAppId);
}
if (!x.includes('com.android.vending.BILLING')) {
  x = x.replace('<application', '<uses-permission android:name="com.android.vending.BILLING" />\n    <application');
}
if (!x.includes('android.permission.INTERNET')) {
  x = x.replace('<application', '<uses-permission android:name="android.permission.INTERNET" />\n    <application');
}
fs.writeFileSync(mf, x);
console.log('OK  AndroidManifest.xml aggiornato (verticale, AdMob ID, billing)');
