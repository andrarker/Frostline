const fs = require('fs'), path = require('path'), vm = require('vm');
module.exports = function loadConfig() {
  const src = fs.readFileSync(path.join(__dirname, '..', 'www', 'config.js'), 'utf8');
  const ctx = { window: {} };
  vm.runInNewContext(src, ctx);
  return ctx.window.FROSTLINE_CONFIG;
};
