# Frostline: dal progetto al Play Store

Cosa serve (una volta sola): **Node.js 20+**, **Android Studio** (con Android SDK), un **account sviluppatore Google Play** (25 USD) e un account **AdMob** (gratuito).

## 1. Personalizza `www/config.js`
- `appId`: es. `com.mariorossi.frostline` (definitivo, non cambia più dopo la pubblicazione)
- `privacyUrl`, `supportEmail`
- Lascia `testMode: true` finché provi l'app (annunci di prova Google, nessun rischio di ban)

## 2. Costruisci il progetto Android
```
npm install
npm run setup
npx cap add android
npm run assets      # genera icone e splash da /assets
npm run sync        # copia il gioco e sistema il manifest
npm run open        # apre Android Studio
```
In Android Studio premi Run con il telefono collegato (debug USB attivo) e prova tutto: gioco, pausa, tasto indietro, negozio, video di prova.

## 3. Pubblica la privacy policy (gratis)
1. Modifica `privacy.html` (nome, email, data).
2. Crea un repository GitHub pubblico `frostline`, carica `privacy.html`, attiva Settings > Pages.
3. L'URL sarà `https://TUOUSERNAME.github.io/frostline/privacy.html`: mettilo in `config.js`.

## 4. AdMob (soldi dalla pubblicità)
1. Su admob.google.com registra l'app (Android) e crea 3 blocchi: **Banner**, **Interstitial**, **Rewarded**.
2. Incolla in `config.js` l'ID app (`~`) e i 3 ID blocco (`/`).
3. Imposta `testMode: false`.

## 5. Play Console
1. Crea l'app (Gioco, Gratuita) e compila le schede come in `store/SCHEDA_STORE.md`.
2. **Monetizzazione > Prodotti > Prodotti in-app**: crea `remove_ads` (una tantum, es. 2,99 EUR) e attivalo.
3. Carica icona, immagine in evidenza e screenshot dal telefono.

## 6. Genera il file da caricare (.aab)
1. `npm run sync`
2. Android Studio: **Build > Generate Signed App Bundle > Android App Bundle**.
3. Crea una nuova keystore, **salvala (con le password) in 2 posti sicuri**: se la perdi non potrai più aggiornare l'app.
4. Per ogni aggiornamento aumenta `versionCode` in `android/app/build.gradle`.

## 7. Test e uscita
Gli account personali nuovi devono fare un **test chiuso con almeno 12 tester per 14 giorni** prima della produzione (verifica i requisiti attuali in Play Console). Poi richiedi l'accesso alla produzione.

## Cose da controllare prima di pubblicare
- [ ] `testMode: false` e ID AdMob veri (lo script `npm run setup` ti avvisa)
- [ ] Provato l'acquisto `remove_ads` da tester di licenza (Play Console > Test licenza)
- [ ] Privacy policy online e link in Play Console
- [ ] Data safety e classificazione compilate
- [ ] Screenshot veri dal telefono
- [ ] Verifica il livello API di destinazione richiesto da Google (aggiorna Capacitor se serve)
