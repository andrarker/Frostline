# Testi per Google Play Console

## Italiano (lingua predefinita)
**Titolo (max 30):** Frostline: corsa nel ghiaccio

**Descrizione breve (max 80):**
Corri, salta e scivola in un canyon di ghiaccio 3D. Quanto vai lontano?

**Descrizione completa:**
Frostline è un runner 3D veloce e preciso: scivola lungo un canyon di ghiaccio, schiva i cristalli, passa sotto le barre e raccogli le monete.

COME SI GIOCA
• Scorri a sinistra e a destra per cambiare corsia
• Scorri in alto per saltare le barriere basse
• Scorri in basso per scivolare sotto le barre
• Le muraglie di cristallo si evitano cambiando corsia

CARATTERISTICHE
• Grafica 3D morbida e colorata, pensata per i telefoni
• Velocità che cresce a ogni metro: ogni partita è diversa
• Sei skin da sbloccare con le monete che raccogli
• Regalo giornaliero con bonus per i giorni consecutivi
• Funziona offline, nessun account richiesto
• Giocabile con una mano

PUBBLICITÀ E ACQUISTI
Il gioco è gratuito con pubblicità. Con un acquisto singolo puoi rimuovere banner e annunci a schermo intero. I video sono sempre facoltativi: guardali solo se vuoi continuare una partita o raddoppiare le monete.

## English (United States)
**Title:** Frostline: Ice Canyon Run
**Short:** Run, jump and slide through a 3D ice canyon. How far can you go?
**Full:**
Frostline is a fast, precise 3D runner. Slide down an icy canyon, dodge crystals, duck under bars and collect coins.

HOW TO PLAY
• Swipe left or right to change lane
• Swipe up to jump low barriers
• Swipe down to slide under bars
• Crystal walls must be avoided by changing lane

FEATURES
• Soft, colourful 3D graphics built for phones
• Speed rises with every metre
• Six skins to unlock with the coins you collect
• Daily gift with streak bonus
• Works offline, no account needed
• One-handed play

ADS AND PURCHASES
Free with ads. A one-time purchase removes banners and full-screen ads. Videos are always optional.

---
## Impostazioni consigliate in Play Console
- Tipo: **App** > Categoria: **Gioco** > **Arcade** (o Azione)
- Gratuita, con annunci: **Sì**. Acquisti in-app: **Sì**
- Pubblico di destinazione: **13+ / 16+** (NON includere under 13, eviti la policy Famiglie)
- Classificazione contenuti: questionario, nessuna violenza/linguaggio/gioco d'azzardo -> di norma PEGI 3 / Everyone
- Prodotto in-app: ID **remove_ads**, tipo "prodotto gestito" (una tantum), prezzo consigliato 2,99 EUR
- Data safety: dichiara la raccolta di "ID dispositivo o altri ID" e "Interazioni con l'app/Diagnostica" per pubblicità (AdMob). Segui la guida ufficiale di AdMob "Play Data safety" per le voci esatte.
- Dichiarazione ID pubblicitario: **Sì** (usato per pubblicità)
- URL privacy policy: quello di GitHub Pages (vedi guida)

## Grafica
- Icona 512x512: `store/icon-512.png`
- Immagine in evidenza 1024x500: `store/feature-graphic-1024x500.png`
- Screenshot (minimo 2, consigliati 4-8, verticali): **fai gli screenshot dal telefono mentre giochi** (menu, partita, negozio, game over).
